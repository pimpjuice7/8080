Please make sure that all the libraries in the current folder are included correctly into AndroratServer.
Otherwise some functionalities will certainly not work. 
